# Remote dependency example

This package exports the constant `GOOD_REMOTE_0_1_0` for a companion npm lockfile example. It has no installation scripts or runtime dependencies.

The versioned archive is intended to remain unchanged at its public URL.
