'use strict'

module.exports = Object.freeze({ value: 'GOOD_REMOTE_0_1_0' })
